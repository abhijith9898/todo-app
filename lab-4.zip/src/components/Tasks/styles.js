import { StyleSheet } from 'react-native';


export default StyleSheet.create({
    container: {
      flex: 10,
      backgroundColor: '#8d9bc9',
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      padding: '3%',
      
    },
    text: {
      color: '#fff',
    },
});